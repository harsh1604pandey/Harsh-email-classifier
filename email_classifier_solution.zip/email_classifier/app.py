from models import train_traditional_model, train_bert_model
import json
import os

if __name__ == "__main__":
    data_path = "data/support_emails.csv"

    print("Training Traditional ML Model...")
    train_traditional_model(data_path)

    print("Training BERT Model...")
    model, tokenizer, id2label = train_bert_model(data_path)

    print("Saving label map for BERT...")
    os.makedirs("model/bert_classifier", exist_ok=True)
    with open("model/bert_classifier/label_map.json", "w") as f:
        json.dump(id2label, f)
