from fastapi import FastAPI, Request, Query
from pydantic import BaseModel
from utils import mask_pii
from models import classify_email_traditional, classify_email_bert
import uvicorn
import json
import os

app = FastAPI()

LABEL_MAP_PATH = "model/bert_classifier/label_map.json"
if os.path.exists(LABEL_MAP_PATH):
    with open(LABEL_MAP_PATH, 'r') as f:
        id2label = json.load(f)
else:
    id2label = {}

class EmailRequest(BaseModel):
    email: str

@app.post("/classify/")
async def classify_email(data: EmailRequest, model: str = Query(default="ml")):
    original_email = data.email
    masked_email, entities = mask_pii(original_email)
    if model == "bert":
        if not id2label:
            return {"error": "BERT model not trained yet"}
        category = classify_email_bert(masked_email, id2label)
    else:
        category = classify_email_traditional(masked_email)
    return {
        "input_email_body": original_email,
        "list_of_masked_entities": entities,
        "masked_email": masked_email,
        "category_of_the_email": category
    }

if __name__ == "__main__":
    uvicorn.run("api:app", host="0.0.0.0", port=8000, reload=True)
