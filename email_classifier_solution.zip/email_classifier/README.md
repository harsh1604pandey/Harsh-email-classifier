# Email Classification API with PII Masking

This project builds and deploys an API to classify support emails and mask PII (Personal Identifiable Information).

## Features
- Detects and masks PII (name, email, phone, card, etc.)
- Classifies emails into categories (e.g., Billing Issues, Technical Support)
- Supports traditional ML and BERT-based models
- Exposes a FastAPI POST API
- Deployable on Hugging Face Spaces

## Setup Instructions

1. **Clone the repo**
   ```bash
   git clone https://github.com/your-username/email-classifier
   cd email-classifier
   ```

2. **Install dependencies**
   ```bash
   pip install -r requirements.txt
   ```

3. **Train models**
   ```bash
   python app.py
   ```

4. **Run the API**
   ```bash
   uvicorn api:app --reload
   ```

## API Usage

### Endpoint
```
POST /classify/?model=ml  # or ?model=bert
```

### Request Body
```json
{
  "email": "Hello, my name is John Doe and my email is johndoe@example.com"
}
```

### Response Format
```json
{
  "input_email_body": "...",
  "list_of_masked_entities": [
    {
      "position": [start_index, end_index],
      "classification": "entity_type",
      "entity": "original_value"
    }
  ],
  "masked_email": "...",
  "category_of_the_email": "..."
}
```

## Deployment (Hugging Face)

1. Create a new Space (FastAPI template).
2. Upload all project files.
3. Add `app.py`, `api.py`, and `requirements.txt`.
4. Add the launch command in `README.md`:
   ```bash
   uvicorn api:app --host 0.0.0.0 --port $PORT
   ```

## Authors
- [Your Name]
